
public class Frame 
{
	String Name;
	Integer Page;
	
	Frame(String NameToSet)
	{
		Name = NameToSet;
		Page = -1;
	}
}
